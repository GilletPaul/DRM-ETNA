drm.js est l'entrypoint pour node

Le gitignore comporte les dossiers de windows, de vscode, de Node et de react